

create database digitalnest;

1)
customer-----table----->cid ,cname ,accno,bal ,address

create ,insert, select , in one program
update a customer bal ,delete a customer ,select data in another program

2)
table----->student---->name,rollno,branch,rank,college
create ,insert, select , in one program
update, delete a student details  ,selectin another program

3)books------>tablename
  cols------->sno,bookname,author,price,year;
 also perform update and delete
