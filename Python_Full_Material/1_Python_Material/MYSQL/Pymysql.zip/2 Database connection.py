Database Connection:
Python Connecting with Database:
    
    Disadvantage of files:
    -we cant apply logic in files,only we can open and close
    
    Advantage of RDBMS:
    -we can apply logic and bring only required data 

    python can connect with different databases like oracle,mysql,DB2,sqlite3 etc
    python connecting to each database, we require seperate module which have
    functions or classes 

    A seperate python module--------->to connect with oracle
    A seperate python module--------->to connect with mysql
    But these modules are not available in python s/w,
    bcoz everybody won't use the database connection,
    these modules are called external modules.

    so using pip,we need to download and install these external modules
    and making it available to python interpreter.

    so we need to install the external modules to communicate with the database
    by using pip

    Pip: pip is a pre-defined application, which is available inside
    installation folder of python s/w,using which we can install all external
    modules such as
    1.Database related external modules
    2.Data analytics related external modules
    3.Automation related external modules
    4.Gui/animations related external modules
    5.Networking related external modules etc. so on......






    
    
    



    
    
    
