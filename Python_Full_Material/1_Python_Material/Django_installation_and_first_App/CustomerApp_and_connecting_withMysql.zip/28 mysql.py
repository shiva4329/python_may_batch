#create SalesApp

#step 3: creating and starting project

(myvenv) C:\djangoapps>django-admin startproject myproj15

(myvenv) C:\djangoapps>cd myproj15

#--------------------------------------------------------------------------------------------------
#step 4: Creating and starting Application

(myvenv) C:\djangoapps\myproj15>python manage.py startapp SalesApp

(myvenv) C:\djangoapps\myproj15>

#--------------------------------------------------------------------------------------------------
#step 5: goto models.py in Application folder(SalesApp).

from django.db import models

# Create your models here.
class Sales(models.Model):
    pid=models.IntegerField()
    pname=models.CharField(max_length=20) #---------makemigrations----> sqlcode generates-----execute
    date=models.DateField()
    price=models.FloatField()               #saying "migrate"---------->Table gets created

#----------------------------------------------------------------------------------------------------
#step 6: add ur application in settings.py ------>installed apps
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'SalesApp'    #addhere
]

-----------------------------------------------------------------------------------------------------
step 7: Goto Mysql database and create a database----->"djangodb1"

-----------------------------------------------------------------------------------------------------
Step 8: goto settings.py and perform the following
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'djangodb1',
        'USER': 'root',
        'PASSWORD':'root'
    }
}

-----------------------------------------------------------------------------------------------------
#step 9: makemigrations
myvenv) C:\djangoapps\myproj15>pip install mysql
(myvenv) C:\djangoapps\myproj15>py manage.py makemigrations #here pythoncode converted to sql code
Migrations for 'SalesApp':
  CustomerApp\migrations\0001_initial.py
    - Create model Customer
#sql generated code, we can see within a python file with
#default name under----> migrations\0001_initial.py

-------------------------------------------------------------------------------------------------
#step 10 :migrate
(venv) C:\Users\DELL\PycharmProjects\myproj15>py manage.py migrate

#-------------------------------------------------------------------------------
#open Views.py and write the following
from django.shortcuts import render
from .models import Sales          #or from SalesApp.models import Sales
from django.http import HttpResponse
def input(request):
    return render(request,'base.html')
def insert(request):
    pid1=int(request.GET['t1'])
    pname1=request.GET['t2']
    price1=float(request.GET['t3'])
    date1=request.GET['t4']
    f=Sales(pid=pid1,pname=pname1,pcost=pcost1,pmfd=pmfd1,pexpdt=pexpd1)
    f.save()
    return HttpResponse("data inserted successfully")
-------------------------------------------------------------------------------
#open base.html
</html>
</body>
</head>
<body bgcolor="#00ffff">
<form action="./insert" method="get">
Enter pid:<input type="text" name="t1"><br>
Enter pname:<input type="text" name="t2"><br>
Enter price:<input type="text" name="t3"><br>
Enter ExpiryDate:<input type="text" name="t4"><br>
   <input type="submit" value="submit">
</form>

</body>
</html>

--------------------------------------------------------------------------------
from django.conf.urls import url
from . import views
app_name='dbinsertapp'
urlpatterns = [
url(r'^$',views.input, name='input'),
url(r'^insert$',views.insert,name='insert'),
]

-------------------------------------------------------------------------------
#step : runserver
#Give Request in the browser

http://127.0.0.1:8000/

Enter pid:101
Enter pname:samsung
Enter price:32000
Enter ExpiryDate:2022-11-19
submit


Data inserted successfully

go and check in Mysql

mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| djangodb1          |
| information_schema |
| mydb1              |
| mydb2              |
| mydb3              |
| mydb4              |
| mydb5              |
| mydb6              |
| mydb7              |
| mysql              |
| performance_schema |
| pythondb1          |
| sakila             |
| sys                |
| world              |
+--------------------+
15 rows in set (0.09 sec)

mysql> use djangodb1;
Database changed
mysql> show tables;
+----------------------------+
| Tables_in_djangodb1        |
+----------------------------+
| auth_group                 |
| auth_group_permissions     |
| auth_permission            |
| auth_user                  |
| auth_user_groups           |
| auth_user_user_permissions |
| django_admin_log           |
| django_content_type        |
| django_migrations          |
| django_session             |
| salesapp_sales             |
+----------------------------+
11 rows in set (0.06 sec)

mysql> select * from salesapp_sales;
Empty set (0.12 sec)

mysql> select * from salesapp_sales;
+----+-----+---------+-------+------------+
| id | pid | pname   | price | date       |
+----+-----+---------+-------+------------+
|  1 | 101 | Samsung | 32000 | 2022-11-19 |
+----+-----+---------+-------+------------+
1 row in set (0.00 sec)

mysql>

--------------------------------------------------------------------------------























