Steps involved :

1)creating Model class  : for table creation
2)makemigrations        :converting python code to sql code
3)migrate               :Executing sql query and table creation
4)Register model class to admin interface(admin.py)
5)Creating superuser  (for every project a superuser) 
6)login to admin interface
7)inserting data
8)retrieve the data and display to the end user.
#-----------------------------------------------------------------------------------------------------
#create a CustomerApp

#step 3: creating and starting project

(myvenv) C:\djangoapps>django-admin startproject myproj18

(myvenv) C:\djangoapps>cd myproj18

#--------------------------------------------------------------------------------------------------
#step 4: Creating and starting Application

(myvenv) C:\djangoapps\myproj18>python manage.py startapp CustomerApp

(myvenv) C:\djangoapps\myproj18>

#--------------------------------------------------------------------------------------------------
#step 5: goto models.py in Application folder(CustomerApp).

from django.db import models

# Create your models here.
class Customer(models.Model):
    cid=models.IntegerField()
    cname=models.CharField(max_length=20) #---------makemigrations----> sqlcode generates-----execute
    dob=models.DateField()
    bal=models.FloatField()               #saying "migrate"---------->Table gets created
    email=models.EmailField()
    phoneno=models.IntegerField()
    address=models.TextField()

#----------------------------------------------------------------------------------------------------
#step 5: add ur application in settings.py ------>installed apps
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'CustomerApp'    #addhere
]
#----------------------------------------------------------------------------------------------------
#step 6: makemigrations

(myvenv) C:\djangoapps\myproj18>py manage.py makemigrations #here pythoncode converted to sql code
Migrations for 'CustomerApp':
  CustomerApp\migrations\0001_initial.py
    - Create model Customer
#sql generated code, we can see within a python file with
#default name under----> migrations\0001_initial.py

#----------------------------------------------------------------------------------------------------
#step 7: goto migrations folder within Application folder(CustomerApp)--->we see-->0001_initial.py

open the file we see the following
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Customer',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('cid', models.IntegerField()),
                ('cname', models.CharField(max_length=20)),
                ('dob', models.DateField()),
                ('bal', models.FloatField()),
                ('email', models.EmailField(max_length=254)),
                ('phoneno', models.IntegerField()),
                ('address', models.TextField()),
            ],
        ),
    ]
#Note : here along with the columns(7) that we specified we get a new column(id) which is generated
#automatically and is taken as primary key column with auto increment of values like 1,2,3,4,5

#----------------------------------------------------------------------------------------------------
#step 8: to see the equivalent sql code for this pythonfile(0001_initial.py) then

(myvenv) C:\djangoapps\myproj18>py manage.py sqlmigrate CustomerApp 0001_initial
BEGIN;
--
-- Create model Customer
--
CREATE TABLE "CustomerApp_customer" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "cid" integer NOT NULL, "cname" varchar(20) NOT NULL, "dob" date NOT NULL, "bal" real NOT NULL, "email" varchar(254) NOT NULL, "phoneno" integer NOT NULL, "address" text NOT NULL);
COMMIT;
#-----------------------------------------------------------------------------------------------------
#step 9: migrate
executing the sqlcode to generate sql table

(myvenv) C:\djangoapps\myproj18>py manage.py migrate
Operations to perform:
  Apply all migrations: CustomerApp, admin, auth, contenttypes, sessions
Running migrations:
  Applying CustomerApp.0001_initial... OK
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
here not only the sql table is generated ,many other tables are generated when we say --->migrate
#here by default we have many in-built applications within this django
#we can see them in the-------> installed apps of settings.py

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',  #in-built applications
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'ModelApp'
]

#above--->when we say migrate-->migrations applied on all these in-built applications
-----------------------------------------------------------------------------------------------------
#step 10: create superuser

#stop server------>ctrl+c

(myvenv) C:\djangoapps\myproj18>py manage.py createsuperuser
Username (leave blank to use 'dell'): vijay
Email address: vijaysundertrainings@gmail.com
Password: python123
Password (again): python123
Superuser created successfully.
---------------------------------------------------------------------------------------------------
#Step 11:start server
(myvenv) C:\djangoapps\myproj17>py manage.py runserver

#step 12: goto browser and open admin interface by giving the following request

http://127.0.0.1:8000/admin
username: vijay
passwoird : python123

django admin console opens-------->but table is not seen---->for that register model to admin interface

#------------------------------------------------------------------------------------------------------
#step 13: register model to admin interface
goto admin.py in Application folder(CustomerApp) and write this

from CustomerApp.models import Customer

class CustomerAdmin(admin.ModelAdmin):
    list_display=['cid','cname','dob','bal','email','phoneno','address']   #list_display is pre-defined
admin.site.register(Customer,CustomerAdmin)

#this modelAdmin class will decide in admin interface, how this model information to be displayed

#Now give request-------->http://127.0.0.1:8000/admin

#now we can see----->customers table (within admin interface)----->here table is empty

#-----------------------------------------------------------------------------------------------------
#step 14: using faker module insert random or fake data into the table


myproj18------>rightclick-------->new file(populate.py) and write the following code

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','myproj18.settings')
import django
django.setup()

from CustomerApp.models import Customer
from faker import Faker
fake=Faker()
from random import *

def gen_phoneno():
    s1=randint(7,9)
    num=str(s1)
    for i in range(9):
        num=num+str(randint(0,9))
    return int(num)

def populate(n):
    for i in range(n):
        fcid=fake.random_int(min=1,max=999)
        fcname=fake.name()
        fdob=fake.date()
        fbal=fake.random_int(10000,70000)
        femail=fake.email()
        fphoneno=gen_phoneno()
        faddress=fake.address()
        cust_record=Customer.objects.get_or_create(cid=fcid,cname=fcname,dob=fdob,bal=fbal,email=femail,phoneno=fphoneno,address=faddress)
populate(30)

#----------------------------------------------------------------------------------------------------
#now stop the server(ctrl+c)
#step 15: 
(myvenv) C:\djangoapps\myproj18>py populate.py

#-------------------------------------------------------------------------------------------------
#step 16: start server
(myvenv) C:\djangoapps\myproj18>py manage.py runserver
#now go and refresh the admin interface----->30 random records will be added to database
#--------------------------------------------------------------------------------------------------
#step 17:

#Now displaying the data present in the database to the enduser

#step:   open views.py and write the following
from django.shortcuts import render
from CustomerApp.models import Customer
# Create your views here.
def customer_input(request):
    customers=Customer.objects.all()
    return render(request,'base.html',{'customers':customers})

#--------------------------------------------------------------------------------------------------
#step 18:
#creating template folder

myproj18---->rightclick------>newfolder--->Name:templates

templates------>rightclick----->newfile---->base.html

now write the following code in base.html

#use bootstrap------>
#goto------>www.getbootstrap.com------>select version 3.3.7------->download bootstap-->copy the 1st link

and paste this link in the head tag of base.html as


<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
   <div class="container">
     <h1>CUSTOMER INFORMATION </h1><hr>
     {% if customers%}
        {%for p in customers%}
          <h2>{{p.cname}} Information</h2><hr>
          <ul>
             <li>CUSTOMER ID:{{p.cid}}</li>
             <li>CUSTOMER DOB:{{p.dob}}</li>
             <li>CUSTOMER BALANCE:{{p.bal}}</li>
             <li>CUSTOMER EMAIL:{{p.email}}</li>
             <li>CUSTOMER PHONE NO:{{p.phoneno}}</li>
             <li>CUSTOMER ADDRESS:{{p.address}}</li>
          </ul>
          <br>
       {%endfor%}
      {%else%}
      <p>Customer Records are not available..
   {%endif%}

#-----------------------------------------------------------------------------------------------------
#step 19: adding templates to settings.py as

   TEMPLATE_DIR=os.path.join(BASE_DIR,'templates')

   and

   TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [TEMPLATE_DIR],
        'APP_DIRS': True,

#----------------------------------------------------------------------------------------------------
#step 20: goto urls.py

from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from CustomerApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^$',views.customer_input)
]

#----------------------------------------------------------------------------------------------------
#step 21: goto browser and give request as

http://127.0.0.1:8000/

OUTPUT:
        
CUSTOMER INFORMATION
Daniel Russell Information
CUSTOMER ID:366
CUSTOMER DOB:June 30, 2010
CUSTOMER BALANCE:58759.0
CUSTOMER EMAIL:annaclark@horton.net
CUSTOMER PHONE NO:7178687678
CUSTOMER ADDRESS:09471 Olson Haven Jameston, MN 78229

Derek Gibson Information
CUSTOMER ID:409
CUSTOMER DOB:Dec. 19, 1988
CUSTOMER BALANCE:54319.0
CUSTOMER EMAIL:peter37@yahoo.com
CUSTOMER PHONE NO:7293866952
CUSTOMER ADDRESS:USCGC Jacobs FPO AP 63714

#------------------------------------------------------------------------------
#step 22: Creating static folder and creating a css file within it.

myproj18------->rightclick----->new folder(Static)
static------->right click  ------->new file------->sample.css'

#------------------------------------------------------------------------------
#step 23: adding this static folder to settings.py

STATIC_DIR=os.path.join(BASE_DIR,'static')

add this at the bottom
STATIC_URL = '/static/'
STATICFILES_DIRS=[STATIC_DIR]
#------------------------------------------------------------------------------
#step 24: goto base.html and include these 2 lines
{%load staticfiles%}
<link rel="stylesheet" href="{%static "sample.css"%}">        
#base.html file is ----------------------------------------------

        
{%load staticfiles%}
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="{%static "sample.css"%}">
</head>
<body>
   <div class="container">
     <h1>CUSTOMER INFORMATION </h1><hr>
     {% if customers%}
        {%for p in customers%}
          <h2>{{p.cname}} Information</h2><hr>
          <ul>
             <li>CUSTOMER ID:{{p.cid}}</li>
             <li>CUSTOMER DOB:{{p.dob}}</li>
             <li>CUSTOMER BALANCE:{{p.bal}}</li>
             <li>CUSTOMER EMAIL:{{p.email}}</li>
             <li>CUSTOMER PHONE NO:{{p.phoneno}}</li>
             <li>CUSTOMER ADDRESS:{{p.address}}</li>
          </ul>
          <br>
       {%endfor%}
      {%else%}
      <p>Customer Records are not available..
   {%endif%}

#------------------------------------------------------------------------------
#step 25: goto sample.css and write the following

body{
    background:red;
    color:white;
}

#go and refresh browser
#o/p
background in red and color in white

#ex:2
#I want haeadings(h1) in center and h2 in yellow color
body{
    background:red;
    color:white;
}
h1{
  text-align:center;
}
h2{
  color:yellow;
}
#------------------------------------------------------------------------------
#step26: filtering data of customers just like where clause

#for that goto views.py and write filtering conditions as
#1) I want those customers whose bal<40000

from django.shortcuts import render
from CustomerApp.models import Customer
# Create your views here.
def customer_input(request):
    #customers=Customer.objects.all()   
    customers=Customer.objects.filter(bal__lt=40000)  #bal<40000
    return render(request,'base.html',{'customers':customers})

#now ago and refresh browser, we get all customers whose bal<40000

#2)I want those customers whose bal>40000
customers=Customer.objects.filter(bal__gt=40000)
#------------------------------------------------------------------
#3) I want those customers whose name starts with "A"

customers=Customer.objects.filter(cname__startswith='A')
#--------------------------------------------------------------------
#4) I want the customer details based on balance in ascending order
customers=Customer.objects.all().order_by('bal')
#----------------------------------------------------------------------
#4) I want the customer details based on balance in descending order
customers=Customer.objects.all().order_by('-bal')
#-----------------------------------------------------------------------

#Total views.py
from django.shortcuts import render
from CustomerApp.models import Customer
# Create your views here.
def customer_input(request):
    #customers=Customer.objects.all()
    #customers=Customer.objects.filter(bal__lt=40000)
    #customers=Customer.objects.filter(bal__gt=40000)
   #customers=Customer.objects.filter(cname__startswith='A')
   #customers=Customer.objects.all().order_by('bal')
   customers=Customer.objects.all().order_by('-bal')
   return render(request,'base.html',{'customers':customers})
#------------------------------------------------------------------------------------------------------














        




























        

        















  
