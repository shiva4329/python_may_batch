

#NewsApp


#working with Bootstrap:


#NewsApp:
welcome to Telengana News

-Political ------>click this----->a new page should open
-Sports              "                   "
-Movies              "                   "
-Health              "                   "



4 urls.py

political
sports
movies
health


#step 1: Open Atom IDE and select djangoapps folder in which virtual environment is installed

#step2 : Activate virtual environment
C:\Users\welcome>cd\

C:\>cd C:\djangoapps\myvenv\Scripts

C:\djangoapps\myvenv\Scripts>activate

(myvenv) C:\djangoapps\myvenv\Scripts>pip install django (if django is not installed)

------------------------------------------------------------------------------------------------------

#step 3: creating and starting project

(myvenv) C:\djangoapps\myvenv\Scripts>cd..

(myvenv) C:\djangoapps\myvenv>cd..

(myvenv) C:\djangoapps>django-admin startproject myproj16

(myvenv) C:\djangoapps>cd myproj16

#--------------------------------------------------------------------------------------------------
#step 4: Creating and starting Application

(myvenv) C:\djangoapps\myproj16>python manage.py startapp NewsApp

(myvenv) C:\djangoapps\myproj16>

#------------------------------------------------------------------------------------------------
#step 5: Create templates folder
myproj16(outer directory)--->rightclick---->newfolder---->NAME:templates


expand myproj16----->rightclick on templates--->newfile---->Name:base.html----->enter



---------------------------------------------------------------------------------------------
#Step 6: Create static folder within project outer directory
myproj16(outer directory)--->rightclick---->newfolder---->NAME:static

expand myproj16----->rightclick on static--->newfolder---->Name:css

css-------->rightclick------>newfile------>name:Tnews.css


----------------------------------------------------------------------------------------------
#create image folder:
expand myproj16----->rightclick on static--->newfolder---->Name:images
now copy ur image in C:/djangoapps/myproj16/static/images-------->paste ur image here


#step 7: Adding templates folder to settings .py

TEMPLATE_DIR=os.path.join(BASE_DIR,'templates')

#TEMPLATES = [
#   {
#        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [TEMPLATE_DIR],   #add here


#goto settings.py and add static folder
now open settings.py and add the path of static folder within it


STATIC_DIR=os.path.join(BASE_DIR,'static')

and goto static line code and add add the following

STATICFILES_DIRS=[STATIC_DIR]

----------------------------------------------------------------------------------------------
#step 8: open views.py

from django.shortcuts import render

def input(request):
    return render(request,'base.html')

#-----------------------------------------------------------------------------------------------
#step : goto project urls.py file and include the following

from django.contrib import admin
from django.urls import path

from django.conf.urls import include
from django.conf.urls import url
from NewsApp import views
urlpatterns = [
path('admin/', admin.site.urls),
url(r'NewsApp/',views.input)
]
#-------------------------------------------------------------------------------------------------

#Adding bootstrap

bootstrap :already predefined css styles in a big file is called bootstrap

bootstrap is a big css file
we no need to specify styles, it automatically it takes care
ex:
    body{
    background: red ;
    color:yellow;
    }

bootstrap cdn                               #cdn------>content delivery n/w

to use bootstap -->

goto getbootstrap.com------>top right corner---->select version 3.3.7 (stable version)
---->click download Bootstrap CDN


#step 10: open base.html 
{%load static%}
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
 <body>
   <h1> welcome to Telangana News Portal!!! </h1>
</body>
</html>

#-------------------------------------------------------------------------------
#step : migrate

(myvenv) C:\djangoapps\myproj16>python manage.py migrate
--------------------------------------------------------------------------------------------
#step  :runserver

(myvenv) C:\djangoapps\myproj16>python manage.py runserver



------------------------------------------------------------------------------------------------------
#step : open browser and give request

http://127.0.0.1:8000/NewsApp


o/p: 
welcome to Telangana News Portal!!!


---------------------------------------------------------------------------------------------------
#in bootstrap----->we have jumbotron( for presentation)

goto getbootstrap.com------->components tab--------->in rightside list---->select jumbotron--->

---->

#base.html
{%load staticfiles%}
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
 <body>
   <div class="jumbotron">
     <div class="container">
        <h1> welcome to Telangana News Portal!!! </h1>
    </div>
  </div>
</body>
</html>

#open one more window and give request and observe old and new output
we get output in style

#for the text to appear in center

<div class="jumbotron" align="center">

#the background to minimize and to get spaces at left and right ,keep jumbotron in div as
<body>
  <div class="container">
   <div class="jumbotron" align="center">
     <div class="container">
        <h1> welcome to Telangana News Portal!!! </h1>
    </div>
  </div>
</div>
</body>

#To display jumbotron at center of the page----->include css file

{%load static%}
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="{%static 'css/sample1.css'%}">
</head>
 <body>
  <div class="container">
   <div class="jumbotron" align="center">
     <div class="container">
        <h1> welcome to Telangana News Portal!!! </h1>
    </div>
  </div>
</div>
</body>
</html>

#open sample1.css
.jumbotron{
  margin-top: 200px;
}

#now refresh the browser.

u get at center

#Now i want 3 buttons---------->goto getbootstrap.com----->jumbotron--->

----->we get div class="jumbotron"

copy the paragraph tag and paste 3 times in base.html and remove the <p> tag from it and give
anchor tag.

{%load static%}
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="{%static 'css/sample1.css'%}">
</head>
 <body>
  <div class="container">
   <div class="jumbotron" align="center">
     <div class="container">
        <h1> welcome to Telangana News Portal!!! </h1>
        <a class="btn btn-primary btn-lg" href="#" role="button">political News</a>
        <a class="btn btn-primary btn-lg" href="#" role="button">Sports News</a>
        <a class="btn btn-primary btn-lg" href="#" role="button">Movie News</a>
    </div>
  </div>
</div>
</body>
</html>


o/P:      welcome to Telangana News Portal!!!
            political News   sports news   Movie News

#Between the buttons i want space--------->then include (&nbsp) in the following

<div class="container">
        <h1> welcome to Telangana News Portal!!! </h1>
        <a class="btn btn-primary btn-lg" href="https://www.thehindu.com/news/" role="button">political News</a>&nbsp&nbsp&nbsp&nbsp
        <a class="btn btn-primary btn-lg" href="#" role="button">Sports News</a>&nbsp&nbsp&nbsp&nbsp
        <a class="btn btn-primary btn-lg" href="#" role="button">Movie News</a>&nbsp&nbsp&nbsp&nbsp
    </div>


#-----------------------------------------------------------------------------------------------------
for colors and images to insert we have a site-------->unsplash.com

In search-------->scenery or landscape or Greenery wall papers or sea images or colors

select a image----->right click------>copy image address----->

#now goto Tnews.css file

body{
     background:url( paste here--->image address)

#Tnews.css
     
.jumbotron{
  margin-top: 200px;
}
body{
    background:url(https://images.unsplash.com/photo-1418985991508-e47386d96a71?ixlib=rb-1.2.1&ixid=eyJh
  }


#here image repeated --------->i doesnt want to repeat then say-->background-repeat: no-repeat;

.jumbotron{
  margin-top: 200px;
}
body{
   background: url(https://images.unsplash.com/photo-1548888171-4013feda1c57?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80);
   background-repeat: no-repeat;

 }

#i want total background to cover with image then say----> background-size: cover;

.jumbotron{
  margin-top: 200px;
}
body{
   background: url(https://images.unsplash.com/photo-1548888171-4013feda1c57?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80);
   background-repeat: no-repeat;
   background-size: cover;
 }

#to change the white background for the text-------> background:red; color:white
.jumbotron{
  margin-top: 200px;
  background: red;
  color:white
}
body{
   background: url(https://images.unsplash.com/photo-1548888171-4013feda1c57?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80);
   background-repeat: no-repeat;
   background-size: cover;
 }
-------------------------------------------------------------------------------------------------
# writing a new view function for political news
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

def input(request):
    return render(request,'base.html')

def political_news_view(request):
    news1="Still RTC Strikes......continuing"
    news2="RTC Bus fares to hike....."
    news3="Jagan warning Babu... to shut everything..."
    news4="Python is the next level language......"
    news5="KCR Opening a new metro station....."
    news6="priyanka Reddy accused sentenced to death..."
    dict1={'news1':news1,'news2':news2,'news3':news3,'news4':news4,'news5':news5,'news6':news6}
    return render(request,'politics.html',dict1)

#---------------------------------------------------------------------------------------------------
#goto templates------->rightclick----->newfile----->politics.html

copy-->base.html and paste it in politics.html and change only the body content


{%load staticfiles%}
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="{%static 'css/sample1.css'%}">
</head>
 <body>
  <h1>TELANGANA NEWS........HEADLINES OF TODAY!!!</h1><hr>
  <ul>
    <li>{{news1}}</li>
    <li>{{news2}}</li>
    <li>{{news3}}</li>
    <li>{{news4}}</li>
    <li>{{news5}}</li>
    <li>{{news6}}</li>
</body>
</html>

#----------------------------------------------------------------------------------------------------
#goto urls.py file

from django.contrib import admin
from django.urls import path

from django.conf.urls import include
from django.conf.urls import url
from NewsApp import views
urlpatterns = [
path('admin/', admin.site.urls),
url(r'^NewsApp/',views.input),
url(r'^politics/',views.political_news_view)

]
#-----------------------------------------------------------------------------------------------------
now goto base.html and within button href give--->/politics

<a class="btn btn-primary btn-lg" href="/politics" role="button">political News</a>&nbsp&nbsp&nbsp&nbsp


#---------------------------------------------------------------------------------------------------
#now refresh----->click political news------->it displays o/p but not in bright colors

so for that------>change-----> color:white  in body tag and take jumbotron later if possible
if priority is taken

goto sample1.css

.jumbotron{
  margin-top: 200px;
  background: red;
  color:white
}
body{
   background: url(https://images.unsplash.com/photo-1548888171-4013feda1c57?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80);
   background-repeat: no-repeat;
   background-size: cover;
   color:yellow
 }

#-----------------------------------------------------------------------------------------------------
include this after body tag  for headings in center and in color
h1{
   text-align:center;
   background:red
   }

#--------------------------------------------------------------------------------------------------
#ul text is too small----->so for that after h1 tag include this
  ul{
    font-size:30px;
  }
#---------------------------------------------------------------------------------------------------
#now we can also add images----->goto c:djangoapps/myproj16/static/images-------->paste some images

now goto polictics.html and add imgtag as



{%load static%}
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="{%static 'css/sample1.css'%}">
</head>
 <body>
  <h1>TELANGANA NEWS........HEADLINES OF TODAY!!!</h1><hr>
  <ul>
    <li>{{news1}}</li>
    <li>{{news2}}</li>
    <li>{{news3}}</li>
    <li>{{news4}}</li>
    <li>{{news5}}</li>
    <li>{{news6}}</li>
    <img src="{%static  'images/charminar.jpg'%}">
</body>
</html>

#----------------------------------------------------------------------------------------------

#refresh and check----->we get image

if the image is too big then------>goto sample1.css file and include this after ul tag

  img{
    width:30%;
    height:300px;
    border:10px solid yellow
  }
#-------------------------------------------------------------------------------------------------

#to have multiple images---->goto politics.py file and add

   <ul>
    <li>{{news1}}</li>
    <li>{{news2}}</li>
    <li>{{news3}}</li>
    <li>{{news4}}</li>
    <li>{{news5}}</li>
    <li>{{news6}}</li>

    <img src="{%static  'images/charminar.jpg'%}">
    <img src="{%static  'images/hyderabad.jpg'%}">
    <img src="{%static  'images/charminar.jpg'%}">
</body>
</html>

#---------------------------------------------------------------------------------------------------
#if u want margins b/w images then goto sample1.css file 

img{
    width:30%;
    height:300px;
    border:10px solid yellow;
    margin:10px
  }

#---------------------------------------------------------------------------------------------------
#sample1.css ------------>applicable to all

#---------------------------------------------------------------------------------------------------
#if u want text to be displayed in uppercase,lowecase or each word starting with uppercase then

<ul>
    <li>{{news1|upper}}</li>
    <li>{{news2|lower}}</li>
    <li>{{news3|title}}</li>
    <li>{{news4}}</li>
    <li>{{news5}}</li>
    <li>{{news6}}</li>








