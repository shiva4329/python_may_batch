<ul>
 <li>CustID:{{cid}}</li>
 <li>Cname:{{cname}}<li>
</ul>


---------------------------------------------------------------------------
1)CustomerApp
2)EmployeeApp Assignment
2)TimeApp

  time<=12-------->Good Morning.
  time<=16 ------->Good Afternoon.
  time<=20 ------->Good Evening.
  else ----------->Good Night.

  date=datetime.datetime.now()
  time=int(strftime("%H"))


  {{ }}------>jinja2 code----->it is neither html or pytho code..
