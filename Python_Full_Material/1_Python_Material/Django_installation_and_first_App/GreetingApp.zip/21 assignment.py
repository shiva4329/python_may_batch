
Assignment

1)EmpApp
  Eid:
  Empname:
  Salary:
  Designation:
  Dno:
          TAX  NETSAL  DETAILS 
          (netsal=sal+HRA-tax)
          if sal b/w 5 to 10LAkhs------>10% tax
             sal b/w 10 to 20 --------->20%
             sal above 20LAkhs--------->30%

         HRA=5%

2)PaymentApp or CutomerApp or BankApp



